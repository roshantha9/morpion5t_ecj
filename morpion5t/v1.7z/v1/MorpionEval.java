package ec.app.morpion5t;

import java.io.BufferedReader;
import java.io.InputStreamReader;

import ec.*;
import ec.simple.*;
import ec.util.*;
import ec.vector.*;

import ec.app.morpion5t.GameMemory;

public class MorpionEval extends Problem implements SimpleProblemForm{
    
	// define the problem
	public void evaluate(final EvolutionState state,
                         final Individual ind,
                         final int subpopulation,
                         final int threadnum)
        {
        if (ind.evaluated) return;

        if (!(ind instanceof IntegerVectorIndividual))
            state.output.fatal("Whoa!  It's not a IntegerVectorIndividual!!!",null);
        
        IntegerVectorIndividual ind2 = (IntegerVectorIndividual)ind;
        		
		int rawfitness = 0;
		
		/*
        for(int x=0; x<ind2.genome.length; x++)       	
        	if (x % 2 == 0) rawfitness += ind2.genome[x];
                else rawfitness -= ind2.genome[x];
        */
		rawfitness = getFitnessFromMSol(ind2.genome);
        if(rawfitness <0){
        	state.output.fatal("Whoa!  Fitness Score returned negative !!",null);
        }
        
		
		// We finish by taking the ABS of rawfitness as mentioned.  By the way,
        // in SimpleFitness, fitness values must be set up so that 0 is <= the worst
        // fitness and +infinity is >= the ideal possible fitness.  Our raw fitness
        // value here satisfies this. 
        //if (rawfitness < 0) rawfitness = -rawfitness;
        if (!(ind2.fitness instanceof SimpleFitness))
            state.output.fatal("Whoa!  It's not a SimpleFitness!!!",null);
        ((SimpleFitness)ind2.fitness).setFitness(state,
                // what the heck, lets normalize the fitness for genome length
                // so it's within float range
                //(float)(((double)rawfitness)/ind2.genome.length),
        		(float)rawfitness,
                //... is the individual ideal?  Indicate here...
                false);
        ind2.evaluated = true;
        }
    
    // helper function to get a fitness score from the morpionSol.exe 
    public int getFitnessFromMSol(int[] genome){
    	
    	
		String[] cmd = new String[ genome.length + 1 ]; 
		cmd[0] = "./linuxLiteMsolitare.exe";  // assumes the executable to be in the current directory
		
		int output_score;
		
		for (int i = 0; i < genome.length; i++) {
			String arg = Integer.toString( genome[i] );
			cmd[i+1] = arg;
		}

		try {
			Process p = Runtime.getRuntime().exec(cmd);
			BufferedReader in = new BufferedReader(new InputStreamReader(p.getInputStream()));
			//String cmdOutput = in.readLine();
			String cmdOutput = "";
			String score = "";
			//String[] result_quads = "";
			String result_lines="";
			while ( (cmdOutput = in.readLine()) != null){				
				result_lines = result_lines + " " + cmdOutput;				
				score = cmdOutput;
			}
			
			result_lines = result_lines.trim();
			
			//update GameMemory
			GameMemory.setBounds(Integer.parseInt(score), result_lines);
			
			// return final fitness val
			return Integer.parseInt(score);
			
		} catch (java.io.IOException e) {
				// put code here to raise an appropriate exeception
				// in ECJ, this might involve calling state.output.fatal()
				
				System.out.println("help!");
				e.printStackTrace();
			return -1;
				
		}	
    }
}