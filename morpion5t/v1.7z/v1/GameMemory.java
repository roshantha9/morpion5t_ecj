package ec.app.morpion5t;

import java.util.*;

public class GameMemory {
	
		// these used to keep track of the bounds
		public static int ind_min=0;
		public static int ind_max=30;
		
		public static int bounds_min =0;
		public static int bounds_max =30;
		
		
		// previous best fitness
		public static int prevBestFitness=0;
		
		// set bounds if current fitness of individual is better
		public static void setBounds(int fitness, String str_result_genome){
			if(fitness > prevBestFitness){
				
				int[] result_genome=_cleanupResults(str_result_genome);
				
				Arrays.sort(result_genome); 
				// new values
				ind_min = result_genome[0];
				ind_max = result_genome[result_genome.length-1];
				
				// new bounds (including offset)
				bounds_min = ind_min+5;
				bounds_max = ind_max+10;
				if(bounds_max > 40)
					bounds_max = 40;
				
				//System.out.println("GameMemory:: "+ind_min+","+ind_max);
				
			}
		}
		
		// helper function
		private static int[] _cleanupResults(String results){
			String split_res[] = results.split(" ");
			
			int i;
			int[] results_genome=new int[split_res.length];
			for(i=0;i<split_res.length-1;i++){
				results_genome[i]=Integer.parseInt(split_res[i]);
			}
			
			return results_genome;
		}
	
}